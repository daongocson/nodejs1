

const getHomepage = async (req, res) => {
    return res.render('sample.ejs')
}

module.exports = {
    getHomepage,

}